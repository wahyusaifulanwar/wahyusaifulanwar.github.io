// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Contr\u00f4leur d\u2019en-t\u00eate",signin:"Connexion",signout:"D\u00e9connexion",about:"A propos",signInTo:"Se connecter \u00e0",cantSignOutTip:"Cette fonction est N/D en mode d\u2019aper\u00e7u.",more:"plus",_localized:{}}});